import 'dart:core';

import 'package:flutter/material.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:memorizator/screens/settings_screen/ad_manager.dart';
import 'package:memorizator/services/constants.dart';

class PurchaseProvider extends ChangeNotifier {
  bool _shopIsAvailable = false;
  bool get isAvailable => _shopIsAvailable;
  List<ProductDetails> _products = [];
  List<ProductDetails> get products => _products;

  DonationStatus _userDonationStatus = DonationStatus.none;
  DonationStatus get userDonationStatus => _userDonationStatus;

  final InAppPurchase _iap = InAppPurchase.instance;
  late Stream<List<PurchaseDetails>> _purchaseStream;

  final AdManager _adManager = AdManager(); // Экземпляр AdManager

  // Пример метода для обновления статуса доната
  void updateDonationStatus(DonationStatus newStatus) {
    _userDonationStatus = newStatus;
    notifyListeners();
  }

  PurchaseProvider() {
    // Проверка покупок
    _initializePurchaseSystem();
    _purchaseStream = _iap.purchaseStream;
    _purchaseStream.listen((purchases) {
      _handlePurchaseUpdates(purchases);
    });
  }

  // Подключааемся к системе покупок, получаем информацию.
  Future<void> _initializePurchaseSystem() async {
    try {
      bool shopAvailable = await _iap.isAvailable();
      _shopIsAvailable = shopAvailable;
      notifyListeners();

      if (_shopIsAvailable) {
        print('Магазин доступен');
        _loadProducts();
      } else {
        print('Магазин недоступен');
      }
    } catch (e) {
      // Если произошла ошибка, обработаем её и покажем сообщение
      _shopIsAvailable = false;
      print('Ошибка подключения к Google Play: $e');
      notifyListeners();
    }
  }

// Загружаем список продуктов из магазина
  Future<void> _loadProducts() async {
    // Получаем ID продуктов
    Set<String> kIds =
        DonationStatus.values.map((e) => e.toString().split('.').last).toSet();
    // ПОлучаем список продуктов из магазина, которые нашлись по нашему списку
    final ProductDetailsResponse response =
        await _iap.queryProductDetails(kIds);
    // Обработка продуктов, которые не были найдены
    if (response.notFoundIDs.isNotEmpty) {}

    _products = response.productDetails;
    notifyListeners();
  }

  // инициация покупки продукта ProductDetails product
  void buyProduct(ProductDetails product) {
    final PurchaseParam purchaseParam = PurchaseParam(productDetails: product);

    // покупаем продукт
    _iap.buyConsumable(
        purchaseParam:
            purchaseParam); // Или buyConsumable, если это одноразовая покупка
  }

  void _handlePurchaseUpdates(List<PurchaseDetails> purchases) {
    for (var purchase in purchases) {
      if (purchase.status == PurchaseStatus.purchased) {
        // Перебираем все значения enum, чтобы найти соответствующий productID
        for (DonationStatus status in DonationStatus.values) {
          if (purchase.productID == status.toString().split('.').last) {
            // Успешная покупка доната
            print('Покупка доната успешно завершена: ${purchase.productID}');
            // Подтверждаем покупку:
            InAppPurchase.instance.completePurchase(purchase);
            // Обновляем статус доната в системе
            updateDonationStatus(status);
            break; // Выходим из цикла, так как продукт найден
          }
        }
      } else if (purchase.status == PurchaseStatus.error) {
        // Обработка ошибок
        print('Ошибка при покупке: ${purchase.error}');
      }

      if (purchase.pendingCompletePurchase) {
        InAppPurchase.instance.completePurchase(purchase); // Завершаем покупку
      }
    }
  }

  void restorePurchases() {
    _iap.restorePurchases();
  }

// Метод для загрузки межстраничной рекламы
  void loadInterstitialAd() {
    _adManager.loadInterstitialAd(); // Вызов метода из AdManager
  }

  // Метод для показа межстраничной рекламы
  void showInterstitialAd() {
    _adManager.showInterstitialAd(); // Вызов метода для показа рекламы
  }
}
