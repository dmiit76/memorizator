import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:intl/intl.dart';
import 'package:memorizator/generated/l10n.dart';
import 'package:memorizator/services/constants.dart';

class Instruction extends StatelessWidget {
  const Instruction({super.key});

  final String instructionRuText = """
# Добро пожаловать в приложение **Меморизатор**!

Наше приложение будет полезно следующим пользователям:
1. Туристам, которые хотят пересчитывать цены чужой страны в привычные цены.
2. Тем, кому нужен быстрый пересчет из одной валюты в другую без арифметических действий. Вы просто вводите сумму и тут же видите её в другой валюте.
3. Пользователям, которые хотят сохранять информацию о товарах и ценах на них. К записи можно добавить фотографию товара и штрих-код. Если приложение имеет разрешение на доступ к геоданным, то сохраняется локация места где была сделана запись о товаре.

## Быстрый старт
- На экране настроек установите две валюты для конвертации. Ели появилась кнопка запроса курса валют, то нажмите на неё и приложение автоматически установит курс одной валюты к другой, если это возможно. Вы так же можете самостоятельно ввести курс в соответствующее поле.
- Для ввода суммы, которую хотите конвертировать или запомнить, используйте текстовое поле вверху главного экрана. Если в настройках вы ввели курс конвертации отличный от 0 и 1, приложение в момент ввода будет сразу пересчитывать введенную сумму и выводить результат.
- Вы можете сохранить результат расчета. Опционально можно добавить фотографии и штрихкод товара. При сохранении задайте название товара и введите вес товара, для того чтобы в дальнейшем понимать стоимость относительно веса.

## Действия с записями
- Просмотр записи - короткое нажатие на названии товара.
- Редактирование записи - долгое нажатие на названии товара.
- Удаление записи - откройте запись на редактирование, нажмите кнопку удаления (красным цветом).
- Фильтр для записей - Нажмите на надпись с информацией о количестве записей, задайте фильтр.

## Сохранение фотографий
Фотографии, которые вы прилагаете к записям, хранятся в папке приложения. Если доступно - на внешнем хранилище. Если его нет - в папке приложения на телефоне. посмотреть куда сохраняются фотографии вы можете на экране настроек, в самом низу.

## Отключение рекламы.
Вы можете отключить рекламу в приложении за символическую цену от 1 доллара. Это будет небольшой благодарностью за мой труд и позволит развивать приложение. Вы можете выбрать увеличенную сумму на ваше усмотрение, если посчитаете мой труд полезным. Благодарю за любое пожертвование.

## Развитие
Вы можете предлагать идеи для улучшения приложения или создания новых приложений. 
Вы можете сообщить о недоработках и они будут исправлены.
Пишите memorizator555@gmail.com

Спасибо, что выбрали нас!
""";

  final String instructionEnText = """
# Welcome to the **Memorizator** app!

### Our application will be useful for the following users:
1. Tourists who want to convert the prices of a foreign country into the usual prices.
2. Those who need a quick conversion from one currency to another without arithmetic operations. You just enter the amount and immediately see it in another currency.
3. Users who want to save information about products and their prices. You can add a product photo and barcode to the record. If the application has permission to access geodata, the location of the place where the record was made is saved.

## Quick start
- On the settings screen, set two currencies for conversion. If there is a button to request exchange rate, tap on it and the application will automatically set the exchange rate of one currency to the other, if possible. You can also enter the rate yourself in the corresponding field.
- To enter the amount you want to convert or memorize, use the text field at the top of the main screen. If you have entered a conversion rate other than 0 and 1 in the settings, the application will immediately recalculate the entered amount and display the result.
- You can save the result of the calculation. Optionally you can add photos and barcode of the product. When saving, specify the name of the item and enter the weight of the item, in order to understand the cost in relation to the weight.

## Actions with records
- View record - short press on the product name.
- Edit record - long press on the product name.
- Delete record - open the record for editing, click the delete button (red color).
- Filter for records - Click on the inscription with information about the number of records, set the filter.

## Saving photos
 The photos you attach to your recordings are stored in the application folder. If available - on external storage. If not available, in the application folder on your phone. to see where your photos are saved, you can see where they are saved on the settings screen at the very bottom.

## Disabling advertising
You can disable ads in the app for a nominal price of \$1 or less. It will be a small gratitude for my labor and will allow to develop the application. You can choose an increased amount at your discretion if you find my labor useful. Thank you for any donation.

## Development
You can suggest ideas to improve the app or create new apps. 
You can report bugs and they will be fixed.
Write to memorizator555@gmail.com

Thank you for choosing us!
""";
  //String instructionText = '';

// String currentLocale = Intl.getCurrentLocale();

  @override
  Widget build(BuildContext context) {
    String instructionText = '';

    if (Intl.getCurrentLocale() == 'ru') {
      instructionText = instructionRuText;
    } else {
      instructionText = instructionEnText;
    }
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        centerTitle: true,
        foregroundColor: aWhite,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_sharp,
          ),
          onPressed: () async {
            Navigator.pop(context);
          },
        ),
        title: Text(
          S.of(context).instructionTitle,
          style: const TextStyle(color: aWhite),
        ),
        //actions: [Icon(Icons.close_outlined), Text('  ')],
        backgroundColor: aBlue,
      ),
      backgroundColor: aLightBlue,
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Markdown(
          data: instructionText,
          styleSheet: MarkdownStyleSheet.fromTheme(Theme.of(context)),
        ),
      ),
    );
  }
}
