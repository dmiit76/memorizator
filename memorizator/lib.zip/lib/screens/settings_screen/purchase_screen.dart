import 'package:flutter/material.dart';
import 'package:memorizator/generated/l10n.dart';
import 'package:memorizator/providers/purchase_provider.dart';
import 'package:memorizator/services/constants.dart';
import 'package:provider/provider.dart';

class PurchaseScreen extends StatelessWidget {
  const PurchaseScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // const myButtonStyle = ButtonStyle(
    //   backgroundColor: WidgetStatePropertyAll(aWhite),
    //   shadowColor: WidgetStatePropertyAll(aGray),
    //   elevation: WidgetStatePropertyAll(20),
    //   padding: WidgetStatePropertyAll(EdgeInsets.all(10)),
    // );
    final purchaseProvider = Provider.of<PurchaseProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(S.of(context).supportTheApp),
        foregroundColor: aWhite,
        backgroundColor: aBlue,
      ),
      backgroundColor: aLightBlue,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              S.of(context).supportUsByRemovingTheAds,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
          Expanded(
            child: purchaseProvider.isAvailable
                ? ListView.builder(
                    itemCount: purchaseProvider.products.length,
                    itemBuilder: (context, index) {
                      final product = purchaseProvider.products[index];
                      return ListTile(
                        title: Text(product.title),
                        subtitle: Text(product.description),
                        trailing: Text(product.price),
                        onTap: () => purchaseProvider.buyProduct(product),
                      );
                    },
                  )
                : Center(
                    child: Text(
                        S.of(context).theStoreIsUnavailableCheckTheConnection),
                  ),
          ),
        ],
      ),
    );
  }
}
