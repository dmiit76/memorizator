class ColorScheme {
  // ColorScheme setColor set
}
